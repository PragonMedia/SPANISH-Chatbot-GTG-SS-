# GG-Chatbot-GTG-SS

sudo /usr/local/bin/deploy-cb-ss.sh
